const MODEL = process.env.GEMINI_MODEL || "gemini-3.6-flash";

function allowedOrigin(origin) {
  const configured = (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);

  // During initial setup, allow browser requests from any origin.
  // For production, set ALLOWED_ORIGINS to your GitHub Pages/Vercel origin.
  if (configured.length === 0) return "*";
  return origin && configured.includes(origin) ? origin : null;
}

module.exports = async function handler(req, res) {
  const origin = req.headers.origin;
  const corsOrigin = allowedOrigin(origin);

  if (corsOrigin) {
    res.setHeader("Access-Control-Allow-Origin", corsOrigin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!process.env.GEMINI_API_KEY) {
    console.error("GEMINI_API_KEY is not configured");
    return res.status(500).json({ error: "AI server is not configured" });
  }

  const body = req.body || {};
  const { contents, jsonMode } = body;

  if (!Array.isArray(contents) || contents.length === 0) {
    return res.status(400).json({ error: "Invalid Gemini request" });
  }

  // Only accept the content shape the existing frontend needs.
  const safeContents = contents.map((content) => ({
    role: content.role === "model" ? "model" : "user",
    parts: Array.isArray(content.parts)
      ? content.parts
          .filter((part) =>
            typeof part.text === "string" ||
            (part.inline_data &&
              typeof part.inline_data.mime_type === "string" &&
              typeof part.inline_data.data === "string")
          )
          .map((part) =>
            part.text !== undefined
              ? { text: part.text }
              : { inline_data: {
                  mime_type: part.inline_data.mime_type,
                  data: part.inline_data.data,
                }}
          )
      : [],
  }));

  const generationConfig = jsonMode
    ? { response_mime_type: "application/json" }
    : undefined;

  const geminiBody = {
    contents: safeContents,
    ...(generationConfig ? { generationConfig } : {}),
  };

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY,
        },
        body: JSON.stringify(geminiBody),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      const message =
        data?.error?.message || `Gemini returned HTTP ${response.status}`;
      return res.status(response.status).json({ error: message });
    }

    const text = (data.candidates?.[0]?.content?.parts || [])
      .map((part) => part.text || "")
      .join("\n")
      .trim();

    if (!text) {
      return res.status(502).json({ error: "Gemini returned no text" });
    }

    return res.status(200).json({ text });
  } catch (error) {
    console.error("Gemini request failed:", error);
    return res.status(502).json({ error: "Unable to reach Gemini" });
  }
};
